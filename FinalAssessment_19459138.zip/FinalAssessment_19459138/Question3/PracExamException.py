class PracExamException (Exception):
	pass
