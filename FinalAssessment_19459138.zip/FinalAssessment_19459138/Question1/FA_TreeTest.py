#
# DSA Final Assessment Question 1 - FA_TreeTest.py
#
# Name : 
# ID   :
#
# 
from FA_BinarySearchTree import *

print(“\n**** Question 1: Testing Trees ****\n”)

# Put your code here
t = FA_BinarySearchTree()

print(“\n**** Tests Complete ****\n”)


