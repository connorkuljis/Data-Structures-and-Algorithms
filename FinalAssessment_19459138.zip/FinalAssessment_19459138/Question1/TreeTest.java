/* TreeTest.java
(2 marks).Given the supplied code for the Binary Search Tree and associated TreeNode  classes,
write  the  method  printEvenValues()  to print  the  nodes with odd values in the tree.
Provide code inTreeTest.java/pyto test its functionality (Hint: you will need to traverse the tree)
*/

