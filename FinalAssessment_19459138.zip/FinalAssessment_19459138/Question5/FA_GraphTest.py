#
# DSA Final Assessment Question 5 - FA_GraphTest.py
#
# Name : 
# ID   :
#
# 
from FA_Graph import *
    

print(“\n**** Question 5: Testing Graphs ****\n”)

g = FA_Graph()


g.displayAsMatrix()

print(“\n**** Tests Complete ****\n”)


