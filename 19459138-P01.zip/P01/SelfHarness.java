import java.util.*;

public class SelfHarness
{
    public static void main(String[] args)
    {
	String filename = "RandomNames7000.csv";
	int[] A = Read.readInts(filename);





    }
}
