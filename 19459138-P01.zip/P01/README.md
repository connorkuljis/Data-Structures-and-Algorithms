README
Data Structures and Algorithms P01:

MergeSort.java - class for testing single sorting method to practice
Person.java - Class file for a Person object - objects are created from a file
Question5.java - Using the 3 sorts, this time with file IO and objects
RandomNames7000.csv - Sample csv of names, followed by a number (ID)
Read.java - Java Class for simple FILEIO
SelfHarness.java - scratch driver code, junk
Sorts.java - Class of 5 different sorting algorithms
SortsTestHarness.java - Driver code for sorting, supplied by university
bubbleAttempt1.txt - sample output
findings.md - paragraph of findings from different sorting methods
formatted-results.txt - exported excel in txt format
results.png - image of formatted results
results.txt - sample output from shell script
results8000.txt - sample output from shell script, increased max (n) to 8000+ 
run.sh - shell script to a parameter sweep for driver code on sorts

