/**
 * DSA Final Assessment Question 1 - FA_TreeTest.java
 *
 * Name : 
 * ID   :
 *
 **/
public class FA_TreeTest
{
	public static void main(String args[])
	{
		System.out.println(“\n**** Question 1: Testing Trees ****\n”);

		// put your code here
			
		System.out.println(“\n**** Tests Complete ****\n”);

	}
	
}
